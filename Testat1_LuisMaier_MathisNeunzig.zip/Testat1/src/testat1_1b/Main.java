package testat1_1b;

public class Main {
	public static void main(String[] args) {
		Zugmanagement.start();
	}
}
