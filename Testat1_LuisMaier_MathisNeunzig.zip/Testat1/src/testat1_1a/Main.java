package testat1_1a;

public class Main {
	public static void main(String[] args) {
		Zugmanagement.start();
	}
}
