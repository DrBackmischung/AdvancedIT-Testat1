package testat1_1a;

public class Zugmanagement {
	
	public static void start() {
		
//		// Beispiel 1
//		Lok l = new Lok();	
//
//		LokThread lok0 = new LokThread(0, l, 1.1D);
//		LokThread lok1 = new LokThread(1, l, 1.0D);
//
//		lok0.start();
//		lok1.start();
		
//		// Beispiel 2
//		Lok l = new Lok();	
//
//		LokThread lok0 = new LokThread(0, l, 1.0D);
//		LokThread lok1 = new LokThread(1, l, 1.1D);
//
//		lok1.start();
//		lok0.start();
		
//		// Beispiel 3
//		Lok l = new Lok();	
//
//		LokThread lok0 = new LokThread(0, l, 10.0D);
//		LokThread lok1 = new LokThread(1, l, 1.0D);
//
//		lok0.start();
//		lok1.start();
		
	}
	
}
